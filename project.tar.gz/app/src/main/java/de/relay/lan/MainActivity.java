package de.relay.lan;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.os.PowerManager;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {

    private EditText hostEt;
    private EditText portEt;
    private EditText psEt;
    private Button btn;
    private TextView logTv;
    private ScrollView scroll;

    private Relay relay;
    private WifiManager.MulticastLock mlock;
    private WifiManager.WifiLock wlock;
    private PowerManager.WakeLock wake;
    private final StringBuilder sb = new StringBuilder();
    private final SimpleDateFormat fmt = new SimpleDateFormat("HH:mm:ss", Locale.GERMANY);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        SharedPreferences prefs = getSharedPreferences("relay", MODE_PRIVATE);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int pad = (int) (16 * getResources().getDisplayMetrics().density);
        root.setPadding(pad, pad * 2, pad, pad);

        TextView title = new TextView(this);
        title.setText("LAN Relay (ohne Werbung)");
        title.setTextSize(22);
        root.addView(title);

        hostEt = new EditText(this);
        hostEt.setHint("Serveradresse");
        hostEt.setSingleLine(true);
        hostEt.setText(prefs.getString("host", "FlammoSMP.florianfleischmann.de"));
        root.addView(hostEt);

        portEt = new EditText(this);
        portEt.setHint("Port");
        portEt.setInputType(InputType.TYPE_CLASS_NUMBER);
        portEt.setText(prefs.getString("port", "19132"));
        root.addView(portEt);

        psEt = new EditText(this);
        psEt.setHint("IP der PlayStation (optional)");
        psEt.setSingleLine(true);
        psEt.setText(prefs.getString("ps", "192.168.178.124"));
        root.addView(psEt);

        btn = new Button(this);
        btn.setText("Starten");
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (relay == null) start();
                else stop();
            }
        });
        root.addView(btn);

        scroll = new ScrollView(this);
        logTv = new TextView(this);
        logTv.setTextSize(13);
        logTv.setGravity(Gravity.TOP);
        scroll.addView(logTv);
        root.addView(scroll, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));

        setContentView(root);

        requestPermissions(new String[]{
                "android.permission.NEARBY_WIFI_DEVICES",
                "android.permission.ACCESS_LOCAL_NETWORK"
        }, 1);
    }

    private void append(String s) {
        sb.append(fmt.format(new Date())).append("  ").append(s).append('\n');
        if (sb.length() > 6000) sb.delete(0, sb.length() - 5000);
        logTv.setText(sb.toString());
        scroll.post(new Runnable() {
            @Override
            public void run() {
                scroll.fullScroll(View.FOCUS_DOWN);
            }
        });
    }

    private void start() {
        String host = hostEt.getText().toString().trim();
        host = host.replace("https://", "").replace("http://", "");
        int slash = host.indexOf('/');
        if (slash >= 0) host = host.substring(0, slash);
        int port = 19132;
        int colon = host.lastIndexOf(':');
        if (colon >= 0) {
            try {
                port = Integer.parseInt(host.substring(colon + 1));
            } catch (Exception ignored) {
            }
            host = host.substring(0, colon);
        } else {
            try {
                port = Integer.parseInt(portEt.getText().toString().trim());
            } catch (Exception ignored) {
            }
        }
        if (host.isEmpty()) {
            append("Bitte Serveradresse eingeben.");
            return;
        }
        String ps = psEt.getText().toString().trim();

        getSharedPreferences("relay", MODE_PRIVATE).edit()
                .putString("host", hostEt.getText().toString().trim())
                .putString("port", portEt.getText().toString().trim())
                .putString("ps", ps).apply();

        try {
            WifiManager wm = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            mlock = wm.createMulticastLock("relay-mc");
            mlock.setReferenceCounted(false);
            mlock.acquire();
            wlock = wm.createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "relay-wifi");
            wlock.setReferenceCounted(false);
            wlock.acquire();
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "relay:cpu");
            wake.acquire();
        } catch (Exception e) {
            append("Sperren-Fehler: " + e.getMessage());
        }

        relay = new Relay(host, port, ps, new Relay.Log() {
            @Override
            public void log(final String s) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        append(s);
                    }
                });
            }
        });
        final Relay r = relay;
        new Thread(new Runnable() {
            @Override
            public void run() {
                r.run();
            }
        }).start();
        btn.setText("Stoppen");
        append("Gestartet. PlayStation: Freunde > LAN-Spiele");
    }

    private void stop() {
        if (relay != null) relay.stop();
        relay = null;
        try {
            if (mlock != null && mlock.isHeld()) mlock.release();
            if (wlock != null && wlock.isHeld()) wlock.release();
            if (wake != null && wake.isHeld()) wake.release();
        } catch (Exception ignored) {
        }
        btn.setText("Starten");
        append("Gestoppt.");
    }

    @Override
    protected void onDestroy() {
        if (relay != null) stop();
        super.onDestroy();
    }
}
