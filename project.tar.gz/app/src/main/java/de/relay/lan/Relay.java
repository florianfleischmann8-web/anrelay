package de.relay.lan;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.SocketAddress;
import java.net.SocketTimeoutException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

public class Relay {

    public interface Log {
        void log(String s);
    }

    private static class Client {
        DatagramSocket up;
        SocketAddress addr;
        volatile long last;
    }

    private static final byte[] MAGIC = {
            0x00, (byte) 0xff, (byte) 0xff, 0x00, (byte) 0xfe, (byte) 0xfe, (byte) 0xfe, (byte) 0xfe,
            (byte) 0xfd, (byte) 0xfd, (byte) 0xfd, (byte) 0xfd, 0x12, 0x34, 0x56, 0x78
    };
    private static final int LAN_PORT = 19132;

    private final String host;
    private final int port;
    private final String psIp;
    private final Log log;
    private final ConcurrentHashMap<String, Client> clients = new ConcurrentHashMap<>();

    private volatile boolean running = true;
    private volatile byte[] pong;
    private DatagramSocket sock;
    private InetSocketAddress server;

    public Relay(String host, int port, String psIp, Log log) {
        this.host = host;
        this.port = port;
        this.psIp = psIp;
        this.log = log;
    }

    public void stop() {
        running = false;
        try {
            if (sock != null) sock.close();
        } catch (Exception ignored) {
        }
        for (Client c : clients.values()) {
            try {
                c.up.close();
            } catch (Exception ignored) {
            }
        }
        clients.clear();
    }

    public void run() {
        try {
            server = new InetSocketAddress(InetAddress.getByName(host), port);
        } catch (Exception e) {
            log.log("Adresse nicht gefunden: " + host);
            return;
        }
        try {
            sock = new DatagramSocket(null);
            sock.setReuseAddress(true);
            sock.setBroadcast(true);
            sock.bind(new InetSocketAddress(LAN_PORT));
        } catch (Exception e) {
            log.log("Port " + LAN_PORT + " ist belegt oder nicht erlaubt: " + e.getMessage());
            return;
        }
        queryPong();
        if (pong != null) {
            log.log("Server antwortet: " + motd());
        } else {
            log.log("WARNUNG: Server antwortet nicht auf Ping.");
        }
        log.log("Relay laeuft -> " + server.getAddress().getHostAddress() + ":" + port);

        new Thread(this::updater).start();
        new Thread(this::announcer).start();

        byte[] buf = new byte[65535];
        while (running) {
            try {
                DatagramPacket p = new DatagramPacket(buf, buf.length);
                sock.receive(p);
                int len = p.getLength();
                if (len == 0) continue;
                int id = buf[0] & 0xff;
                if (id == 0x1c) continue;
                byte[] cached = pong;
                if ((id == 1 || id == 2) && cached != null && len >= 9) {
                    byte[] reply = Arrays.copyOf(cached, cached.length);
                    reply[0] = 0x1c;
                    System.arraycopy(buf, 1, reply, 1, 8);
                    sock.send(new DatagramPacket(reply, reply.length, p.getSocketAddress()));
                    continue;
                }
                String key = p.getAddress().getHostAddress() + ":" + p.getPort();
                Client c = clients.get(key);
                if (c == null) {
                    c = new Client();
                    c.up = new DatagramSocket();
                    c.addr = p.getSocketAddress();
                    c.last = System.currentTimeMillis();
                    clients.put(key, c);
                    log.log("Neuer Client: " + key);
                    final Client cc = c;
                    final String k = key;
                    new Thread(() -> pump(k, cc)).start();
                }
                c.last = System.currentTimeMillis();
                logId(id, "-> Server", len);
                c.up.send(new DatagramPacket(Arrays.copyOf(buf, len), len, server));
            } catch (Exception e) {
                if (!running) break;
            }
        }
    }

    private void pump(String key, Client c) {
        byte[] buf = new byte[65535];
        try {
            c.up.setSoTimeout(5000);
            while (running && System.currentTimeMillis() - c.last < 120000) {
                try {
                    DatagramPacket p = new DatagramPacket(buf, buf.length);
                    c.up.receive(p);
                    c.last = System.currentTimeMillis();
                    int len = p.getLength();
                    if (len > 0) logId(buf[0] & 0xff, "<- Server", len);
                    sock.send(new DatagramPacket(Arrays.copyOf(buf, len), len, c.addr));
                } catch (SocketTimeoutException ignored) {
                }
            }
        } catch (Exception ignored) {
        } finally {
            try {
                c.up.close();
            } catch (Exception ignored) {
            }
            clients.remove(key);
        }
    }

    private void logId(int id, String dir, int len) {
        String n = null;
        switch (id) {
            case 5: n = "CONNECT-1"; break;
            case 6: n = "ANTWORT-1"; break;
            case 7: n = "CONNECT-2"; break;
            case 8: n = "ANTWORT-2"; break;
            case 0x19: n = "FALSCHE-VERSION"; break;
            case 0x1a: n = "SERVER-VOLL"; break;
            case 0x17: n = "BANNED"; break;
            default: break;
        }
        if (n != null) log.log(dir + " " + n + " (" + len + " B)");
    }

    private String motd() {
        byte[] p = pong;
        if (p == null || p.length < 35) return "";
        String s = new String(p, 35, p.length - 35, StandardCharsets.UTF_8);
        return s.length() > 70 ? s.substring(0, 70) : s;
    }

    private void updater() {
        while (running) {
            try {
                Thread.sleep(5000);
            } catch (InterruptedException e) {
                return;
            }
            queryPong();
        }
    }

    private void queryPong() {
        DatagramSocket s = null;
        try {
            s = new DatagramSocket();
            s.setSoTimeout(2000);
            byte[] ping = new byte[33];
            ping[0] = 0x01;
            putLong(ping, 1, System.currentTimeMillis());
            System.arraycopy(MAGIC, 0, ping, 9, 16);
            byte[] rnd = new byte[8];
            new Random().nextBytes(rnd);
            System.arraycopy(rnd, 0, ping, 25, 8);
            s.send(new DatagramPacket(ping, ping.length, server));
            byte[] buf = new byte[4096];
            DatagramPacket p = new DatagramPacket(buf, buf.length);
            s.receive(p);
            int len = p.getLength();
            if (len < 35 || (buf[0] & 0xff) != 0x1c) return;
            int n = ((buf[33] & 0xff) << 8) | (buf[34] & 0xff);
            n = Math.min(n, len - 35);
            String txt = new String(buf, 35, n, StandardCharsets.UTF_8);
            String[] parts = txt.split(";", -1);
            if (parts.length > 1 && !parts[1].startsWith("[Relay]")) {
                parts[1] = "[Relay] " + parts[1];
            }
            byte[] nb = String.join(";", parts).getBytes(StandardCharsets.UTF_8);
            byte[] res = new byte[35 + nb.length];
            System.arraycopy(buf, 0, res, 0, 33);
            res[33] = (byte) ((nb.length >> 8) & 0xff);
            res[34] = (byte) (nb.length & 0xff);
            System.arraycopy(nb, 0, res, 35, nb.length);
            pong = res;
        } catch (Exception ignored) {
        } finally {
            if (s != null) s.close();
        }
    }

    private static void putLong(byte[] b, int off, long v) {
        for (int i = 7; i >= 0; i--) {
            b[off + i] = (byte) (v & 0xff);
            v >>= 8;
        }
    }

    private String ownIp() {
        DatagramSocket t = null;
        try {
            t = new DatagramSocket();
            t.connect(InetAddress.getByName("8.8.8.8"), 80);
            return t.getLocalAddress().getHostAddress();
        } catch (Exception e) {
            return "192.168.178.1";
        } finally {
            if (t != null) t.close();
        }
    }

    private void announcer() {
        List<InetSocketAddress> targets = new ArrayList<>();
        try {
            targets.add(new InetSocketAddress(InetAddress.getByName("255.255.255.255"), LAN_PORT));
            String ip = ownIp();
            String bc = ip.substring(0, ip.lastIndexOf('.')) + ".255";
            targets.add(new InetSocketAddress(InetAddress.getByName(bc), LAN_PORT));
            if (psIp != null && !psIp.isEmpty()) {
                targets.add(new InetSocketAddress(InetAddress.getByName(psIp), LAN_PORT));
                targets.add(new InetSocketAddress(InetAddress.getByName(psIp), LAN_PORT + 1));
            }
        } catch (Exception e) {
            log.log("Ankuendigung: Adressfehler " + e.getMessage());
        }
        log.log("Sende Ankuendigung an " + targets.size() + " Ziele");
        Set<String> bad = new HashSet<>();
        while (running) {
            byte[] p = pong;
            if (p != null) {
                byte[] msg = Arrays.copyOf(p, p.length);
                msg[0] = 0x1c;
                putLong(msg, 1, System.currentTimeMillis());
                for (InetSocketAddress t : targets) {
                    try {
                        sock.send(new DatagramPacket(msg, msg.length, t));
                    } catch (Exception e) {
                        String k = t.getAddress().getHostAddress() + ":" + t.getPort();
                        if (bad.add(k)) log.log("Senden fehlgeschlagen: " + k + " (" + e.getMessage() + ")");
                    }
                }
            }
            try {
                Thread.sleep(2000);
            } catch (InterruptedException e) {
                return;
            }
        }
    }
}
